package hr.algreba.pi.hardwareapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HardwareappApplicationTests {

    @Test
    void contextLoads() {
    }

}
