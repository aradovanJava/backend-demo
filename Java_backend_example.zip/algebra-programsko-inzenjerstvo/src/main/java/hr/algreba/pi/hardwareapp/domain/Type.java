package hr.algreba.pi.hardwareapp.domain;

public enum Type {
    CPU, GPU, MBO, RAM, STORAGE, OTHER
}
